var vpee_8c =
[
    [ "Aprx_estDualProblem", "vpee_8c.html#ae04f1d0dc94a41047c4598b5ac26e2dd", null ],
    [ "Aprx_estLocalProblem", "vpee_8c.html#a8205dfab9f94c27701c445c34d8bf9ae", null ],
    [ "Aprx_estNonlinResid", "vpee_8c.html#a40cee95acbd3708ebe22283334f6e2bb", null ],
    [ "Vpee_ctor", "vpee_8c.html#gaade63165c1991fc0172528a3feaf52be", null ],
    [ "Vpee_ctor2", "vpee_8c.html#gad6e9e7022507e08ee70d0fbb73acca06", null ],
    [ "Vpee_dtor", "vpee_8c.html#ga88b173f27d21f94fc5bc25204a0dd328", null ],
    [ "Vpee_dtor2", "vpee_8c.html#ga679f6f6ff388e2968034325274dbcce6", null ],
    [ "Vpee_markRefine", "vpee_8c.html#gad2f2b2a19e77d83756bda1126bbc89a0", null ],
    [ "Vpee_numSS", "vpee_8c.html#ga52a70a6c75250cca20a99563c0fef42c", null ],
    [ "Vpee_ourSimp", "vpee_8c.html#a6598dd50896b21ca504335b523a727f4", null ],
    [ "Vpee_userDefined", "vpee_8c.html#aa8ebb3ab8ad0ae3ab0db6e3330beb33b", null ]
];