var searchData=
[
  ['b',['B',['../structs_vfetk___local_var.html#adf085adbf76beb194ac436d42cd1d725',1,'sVfetk_LocalVar']]],
  ['bcfl',['bcfl',['../structs_p_b_eparm.html#a309c773e3e7c928a3e7a7e8e356d85a6',1,'sPBEparm::bcfl()'],['../structs_vopot.html#a309c773e3e7c928a3e7a7e8e356d85a6',1,'sVopot::bcfl()'],['../structs_vpmgp.html#a309c773e3e7c928a3e7a7e8e356d85a6',1,'sVpmgp::bcfl()']]],
  ['bconc',['bconc',['../structs_a_p_o_lparm.html#aabbbf7db3868a11d4f94b5f4874fa270',1,'sAPOLparm']]],
  ['bemparm',['bemparm',['../structs_n_osh__calc.html#a686f81c337a84906de51807521868880',1,'sNOsh_calc']]],
  ['bogus',['bogus',['../structs_n_osh.html#afdd80a1bfafbeff93fef8424576e4b8e',1,'sNOsh']]],
  ['bpts',['bpts',['../structs_vacc_surf.html#ae9cda9090b538a29358b87cb56e5c779',1,'sVaccSurf']]],
  ['bulkionicstrength',['bulkIonicStrength',['../structs_vpbe.html#a1f36bb212a9ae81e2d34a2224860af4b',1,'sVpbe']]]
];
