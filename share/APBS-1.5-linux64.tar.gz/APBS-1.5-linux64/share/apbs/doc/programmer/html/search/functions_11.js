var searchData=
[
  ['zlapsolve',['zlapSolve',['../vpmg_8c.html#a3667719ad7b6d35bb4ac587513be8b5c',1,'zlapSolve(Vpmg *thee, double **solution, double **source, double **work1):&#160;vpmg.c'],['../vpmg_8h.html#a3667719ad7b6d35bb4ac587513be8b5c',1,'zlapSolve(Vpmg *thee, double **solution, double **source, double **work1):&#160;vpmg.c']]]
];
