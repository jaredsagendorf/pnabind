var vpmgp_8c =
[
    [ "coarsenThis", "vpmgp_8c.html#a57f3050f95570acd05bad050928b7479", null ],
    [ "Vpmgp_ctor", "vpmgp_8c.html#gacbf93b72154285b4a1789400f6cb5aa2", null ],
    [ "Vpmgp_ctor2", "vpmgp_8c.html#ga11a970ff00cb1de38da826b8f1ae6e2a", null ],
    [ "Vpmgp_dtor", "vpmgp_8c.html#ga34b2134038fac6b41b02e67492105c07", null ],
    [ "Vpmgp_dtor2", "vpmgp_8c.html#ga0362aaae83d2078bdb2e555a4b2fc00c", null ],
    [ "Vpmgp_makeCoarse", "vpmgp_8c.html#ga0b65b886427a0d09e8ace8d117e7e0ea", null ],
    [ "Vpmgp_size", "vpmgp_8c.html#gadb713e70f5724ce0f63ec4cf380278d7", null ]
];