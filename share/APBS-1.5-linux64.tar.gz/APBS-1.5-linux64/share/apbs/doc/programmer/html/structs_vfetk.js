var structs_vfetk =
[
    [ "am", "structs_vfetk.html#a2aa6e705d75fbe06547d2047e525ae71", null ],
    [ "aprx", "structs_vfetk.html#ab28b2df11cfe4e02fdd0438d0ab95c9a", null ],
    [ "csm", "structs_vfetk.html#ad107d7fa92f38664a9c1d0bcf9a7ed0c", null ],
    [ "feparm", "structs_vfetk.html#af606ea3c8858a767a799ce2cfbb4c5bc", null ],
    [ "gm", "structs_vfetk.html#a47e3990f869cc9afbc7c5ef756dd6236", null ],
    [ "gues", "structs_vfetk.html#aa50ef50e88ad8f5ec9b1e5677106969d", null ],
    [ "level", "structs_vfetk.html#acf4d33ee4cff36f69b924471174dcb11", null ],
    [ "lkey", "structs_vfetk.html#a9e46438c4cb5647402bb9bd552319c77", null ],
    [ "lmax", "structs_vfetk.html#a880eb260d9da52a83b315907eef5a40f", null ],
    [ "lprec", "structs_vfetk.html#aaba6dc12c9b2f5f542a8a1d32f009472", null ],
    [ "ltol", "structs_vfetk.html#a212a9eb6904ae8996f77b70c34853aba", null ],
    [ "nkey", "structs_vfetk.html#adee1dadcb4b1dac8fdc5c1a5fe4e3fc9", null ],
    [ "nmax", "structs_vfetk.html#aa815e65e74ec006bfacba310c6e8dc9b", null ],
    [ "ntol", "structs_vfetk.html#a9353589cc1064c3565bdfa08e2d2c44b", null ],
    [ "pbe", "structs_vfetk.html#a31a61d9da3a83d7c0328aaaffc6f9a8d", null ],
    [ "pbeparm", "structs_vfetk.html#afaf61d9a316e61af4df6abbc8a9c3018", null ],
    [ "pde", "structs_vfetk.html#a40828aff37933323da2a823d9fd547fc", null ],
    [ "pjac", "structs_vfetk.html#aedfc77966c9f379f799ec4458445438e", null ],
    [ "type", "structs_vfetk.html#a3e9698a7679608b7870c4c957f02ed84", null ],
    [ "vmem", "structs_vfetk.html#adfacdf16f7a3cf04b35f4821208b5bdd", null ]
];