var searchData=
[
  ['setpartmg',['setPartMG',['../group___frontend.html#ga41df35dc86c5b01b663dfd839132f4ae',1,'setPartMG(NOsh *nosh, MGparm *mgparm, Vpmg *pmg):&#160;routines.c'],['../group___frontend.html#ga41df35dc86c5b01b663dfd839132f4ae',1,'setPartMG(NOsh *nosh, MGparm *mgparm, Vpmg *pmg):&#160;routines.c']]],
  ['solvefe',['solveFE',['../group___frontend.html#ga6a4624f3eca6853e163fce9a2109eb1d',1,'solveFE(int icalc, PBEparm *pbeparm, FEMparm *feparm, Vfetk *fetk[NOSH_MAXCALC]):&#160;routines.c'],['../group___frontend.html#ga6a4624f3eca6853e163fce9a2109eb1d',1,'solveFE(int i, PBEparm *pbeparm, FEMparm *feparm, Vfetk *fetk[NOSH_MAXCALC]):&#160;routines.c']]],
  ['solvemg',['solveMG',['../group___frontend.html#ga0fd05f7639a0ceddcafa33cd78590b10',1,'solveMG(NOsh *nosh, Vpmg *pmg, MGparm_CalcType type):&#160;routines.c'],['../group___frontend.html#ga0fd05f7639a0ceddcafa33cd78590b10',1,'solveMG(NOsh *nosh, Vpmg *pmg, MGparm_CalcType type):&#160;routines.c']]],
  ['splineacc',['splineAcc',['../vacc_8c.html#a2a318b9e1df4d9a97ac47cf55498c4a8',1,'vacc.c']]],
  ['startvio',['startVio',['../group___frontend.html#ga293142ab2ee176f2a9c6b3df3ef7917d',1,'startVio():&#160;routines.c'],['../group___frontend.html#ga293142ab2ee176f2a9c6b3df3ef7917d',1,'startVio():&#160;routines.c']]],
  ['storeatomenergy',['storeAtomEnergy',['../group___frontend.html#ga0e7cb685e811533bf5be5a5af174d5d4',1,'storeAtomEnergy(Vpmg *pmg, int icalc, double **atomEnergy, int *nenergy):&#160;routines.c'],['../group___frontend.html#ga0e7cb685e811533bf5be5a5af174d5d4',1,'storeAtomEnergy(Vpmg *pmg, int icalc, double **atomEnergy, int *nenergy):&#160;routines.c']]]
];
