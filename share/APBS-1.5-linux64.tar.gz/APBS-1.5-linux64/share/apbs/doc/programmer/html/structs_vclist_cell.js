var structs_vclist_cell =
[
    [ "atoms", "structs_vclist_cell.html#a1b9fd0d713b19b878664481238523149", null ],
    [ "natoms", "structs_vclist_cell.html#a2093ca3426a8f98873fe165a55bfa2b1", null ]
];