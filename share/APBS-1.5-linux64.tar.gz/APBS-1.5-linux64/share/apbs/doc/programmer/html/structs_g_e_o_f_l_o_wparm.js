var structs_g_e_o_f_l_o_wparm =
[
    [ "etol", "structs_g_e_o_f_l_o_wparm.html#a7b76a8eaa9fe5508943674440942ca1e", null ],
    [ "parsed", "structs_g_e_o_f_l_o_wparm.html#a2eda17f70de002520ab4f15af1c3b415", null ],
    [ "setvdw", "structs_g_e_o_f_l_o_wparm.html#ad4d96d0f644769d9999d3770843d63e7", null ],
    [ "type", "structs_g_e_o_f_l_o_wparm.html#a483ccd53d56840b5353c0e9c62a3255f", null ],
    [ "vdw", "structs_g_e_o_f_l_o_wparm.html#a4da113ca8f0e26b215d8926913041045", null ]
];