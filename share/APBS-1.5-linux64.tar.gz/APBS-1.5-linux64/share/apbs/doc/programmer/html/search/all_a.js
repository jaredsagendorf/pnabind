var searchData=
[
  ['kappa',['kappa',['../structs_vpmg.html#ac6b30598dfa3fffe97620639ad0e12ff',1,'sVpmg']]],
  ['kappafmt',['kappafmt',['../structs_n_osh.html#abae56074a00564a6a34218263ba31ae5',1,'sNOsh']]],
  ['kappamap',['kappaMap',['../structs_vpmg.html#aa3ffd50808f24b927e1828a3e2aacdd7',1,'sVpmg']]],
  ['kappamapid',['kappaMapID',['../structs_p_b_eparm.html#a3f2cba75ae66c1b1b0804abc341bb472',1,'sPBEparm']]],
  ['kappapath',['kappapath',['../structs_n_osh.html#a7577971b4742f23bb79c3e20b6263707',1,'sNOsh']]],
  ['key',['key',['../structs_vpmgp.html#a35af0be900467fedbb610bd6ea65ed78',1,'sVpmgp']]],
  ['killchargemaps',['killChargeMaps',['../group___frontend.html#gafb34b71448f40d24790989412f67abf9',1,'killChargeMaps(NOsh *nosh, Vgrid *map[NOSH_MAXMOL]):&#160;routines.c'],['../group___frontend.html#gafb34b71448f40d24790989412f67abf9',1,'killChargeMaps(NOsh *nosh, Vgrid *charge[NOSH_MAXMOL]):&#160;routines.c']]],
  ['killdielmaps',['killDielMaps',['../group___frontend.html#ga5e888082a91ae3153af5869ae2906b54',1,'killDielMaps(NOsh *nosh, Vgrid *dielXMap[NOSH_MAXMOL], Vgrid *dielYMap[NOSH_MAXMOL], Vgrid *dielZMap[NOSH_MAXMOL]):&#160;routines.c'],['../group___frontend.html#ga5e888082a91ae3153af5869ae2906b54',1,'killDielMaps(NOsh *nosh, Vgrid *dielXMap[NOSH_MAXMOL], Vgrid *dielYMap[NOSH_MAXMOL], Vgrid *dielZMap[NOSH_MAXMOL]):&#160;routines.c']]],
  ['killenergy',['killEnergy',['../group___frontend.html#ga72f1b6552e026ee731a287681ed17c71',1,'killEnergy():&#160;routines.c'],['../group___frontend.html#ga72f1b6552e026ee731a287681ed17c71',1,'killEnergy():&#160;routines.c']]],
  ['killfe',['killFE',['../group___frontend.html#ga9c020a139b1d9101f76942cfd50801a0',1,'killFE(NOsh *nosh, Vpbe *pbe[NOSH_MAXCALC], Vfetk *fetk[NOSH_MAXCALC], Gem *gm[NOSH_MAXMOL]):&#160;routines.c'],['../group___frontend.html#ga9c020a139b1d9101f76942cfd50801a0',1,'killFE(NOsh *nosh, Vpbe *pbe[NOSH_MAXCALC], Vfetk *fetk[NOSH_MAXCALC], Gem *gem[NOSH_MAXMOL]):&#160;routines.c']]],
  ['killflag',['killFlag',['../structs_vpee.html#a59361f6b66004c04caaee1a28736841c',1,'sVpee']]],
  ['killforce',['killForce',['../group___frontend.html#ga0e4a70bef79f7f91153fbde385c3685b',1,'killForce(Vmem *mem, NOsh *nosh, int nforce[NOSH_MAXCALC], AtomForce *atomForce[NOSH_MAXCALC]):&#160;routines.c'],['../group___frontend.html#ga0e4a70bef79f7f91153fbde385c3685b',1,'killForce(Vmem *mem, NOsh *nosh, int nforce[NOSH_MAXCALC], AtomForce *atomForce[NOSH_MAXCALC]):&#160;routines.c']]],
  ['killkappamaps',['killKappaMaps',['../group___frontend.html#ga2f3ca539647fa494f258b9fed6b9a774',1,'killKappaMaps(NOsh *nosh, Vgrid *map[NOSH_MAXMOL]):&#160;routines.c'],['../group___frontend.html#ga2f3ca539647fa494f258b9fed6b9a774',1,'killKappaMaps(NOsh *nosh, Vgrid *kappa[NOSH_MAXMOL]):&#160;routines.c']]],
  ['killmeshes',['killMeshes',['../group___frontend.html#ga499297ca1cf87a3808d7152de94ab5ed',1,'routines.h']]],
  ['killmg',['killMG',['../group___frontend.html#ga650776f55f2f078455a67050c9545f17',1,'killMG(NOsh *nosh, Vpbe *pbe[NOSH_MAXCALC], Vpmgp *pmgp[NOSH_MAXCALC], Vpmg *pmg[NOSH_MAXCALC]):&#160;routines.c'],['../group___frontend.html#ga650776f55f2f078455a67050c9545f17',1,'killMG(NOsh *nosh, Vpbe *pbe[NOSH_MAXCALC], Vpmgp *pmgp[NOSH_MAXCALC], Vpmg *pmg[NOSH_MAXCALC]):&#160;routines.c']]],
  ['killmolecules',['killMolecules',['../group___frontend.html#ga7b6f501f213ee48d2ece5bc0b6cac635',1,'killMolecules(NOsh *nosh, Valist *alist[NOSH_MAXMOL]):&#160;routines.c'],['../group___frontend.html#ga7b6f501f213ee48d2ece5bc0b6cac635',1,'killMolecules(NOsh *nosh, Valist *alist[NOSH_MAXMOL]):&#160;routines.c']]],
  ['killparam',['killParam',['../structs_vpee.html#a966b9fe0a90ea2a0b15ff761376211e2',1,'sVpee']]],
  ['killpotmaps',['killPotMaps',['../group___frontend.html#ga9a917393b19c6f490fe889d548055270',1,'killPotMaps(NOsh *nosh, Vgrid *map[NOSH_MAXMOL]):&#160;routines.c'],['../group___frontend.html#ga9a917393b19c6f490fe889d548055270',1,'killPotMaps(NOsh *nosh, Vgrid *pot[NOSH_MAXMOL]):&#160;routines.c']]]
];
