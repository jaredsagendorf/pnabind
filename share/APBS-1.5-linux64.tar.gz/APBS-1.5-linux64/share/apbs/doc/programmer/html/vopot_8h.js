var vopot_8h =
[
    [ "Vopot", "vopot_8h.html#gab0d4ff9b02d756dca6d2c80c95c02ca6", null ],
    [ "Vopot_ctor", "vopot_8h.html#ga862aab44348b5b3527a81899cd436676", null ],
    [ "Vopot_ctor2", "vopot_8h.html#ga76c87497536572225a18c060f4379dc2", null ],
    [ "Vopot_curvature", "vopot_8h.html#gaf6a3279fcbed2618e526fc075196a41a", null ],
    [ "Vopot_dtor", "vopot_8h.html#ga7a32a04e77f23eb310ce23ce9b4ecf6b", null ],
    [ "Vopot_dtor2", "vopot_8h.html#ga24bea2338d4004ac24e8dd1a30a68d42", null ],
    [ "Vopot_gradient", "vopot_8h.html#ga5fd9d88ed744980aff8ea40eb1b10077", null ],
    [ "Vopot_pot", "vopot_8h.html#gaec11bf9879fe1d94313b5a6c9dda57e6", null ]
];