var structs_vacc =
[
    [ "acc", "structs_vacc.html#a7bfa5e4be0ddf36c67ccef57cbc70fc6", null ],
    [ "alist", "structs_vacc.html#ae0b1ff92bae2d15bb71adebfe53bbc17", null ],
    [ "atomFlags", "structs_vacc.html#a671bddd3aa0c09139e62394fad314364", null ],
    [ "clist", "structs_vacc.html#a957d15a1c5bd8832a22698b8e507793a", null ],
    [ "mem", "structs_vacc.html#a1fd4c83b7f1c23dd45932b41a8fc97ab", null ],
    [ "refSphere", "structs_vacc.html#aeeef392d16dcd45b5781780ab5afd6d2", null ],
    [ "surf", "structs_vacc.html#aefa4d392884be3b2e641a83d67ee664e", null ],
    [ "surf_density", "structs_vacc.html#a72aa036c519bf25e99ad4d43241fb33c", null ]
];