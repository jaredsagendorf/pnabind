var structs_p_b_s_a_mparm =
[
    [ "density", "structs_p_b_s_a_mparm.html#a6f8c052f8417728038991f7f2826d38d", null ],
    [ "expct", "structs_p_b_s_a_mparm.html#a42cb304d076847f52def9055d8277af0", null ],
    [ "expfil", "structs_p_b_s_a_mparm.html#a8fa0e31af59466d80bbaa194ddb876f2", null ],
    [ "imatct", "structs_p_b_s_a_mparm.html#a9761d2194c1bf0664ca9573802194744", null ],
    [ "imatfil", "structs_p_b_s_a_mparm.html#a56e6b39230b7df9d90047508bfae7b36", null ],
    [ "parsed", "structs_p_b_s_a_mparm.html#a2eda17f70de002520ab4f15af1c3b415", null ],
    [ "probe_radius", "structs_p_b_s_a_mparm.html#a8c6c90a23abc7b51c35243216f21940c", null ],
    [ "setexp", "structs_p_b_s_a_mparm.html#a56f5b0c29d7e6f049af7e13a7b2ae0f9", null ],
    [ "setimat", "structs_p_b_s_a_mparm.html#a4c6d7e938ec54a44baafad5fc090bb56", null ],
    [ "setmsms", "structs_p_b_s_a_mparm.html#add2cad0da93a851ecd3bea0b70cbc629", null ],
    [ "setsurf", "structs_p_b_s_a_mparm.html#a5ddf2303988d2cb700e74b6a6bcae8cc", null ],
    [ "settolsp", "structs_p_b_s_a_mparm.html#a7d81b4885103769bdb07babd5931de96", null ],
    [ "surfct", "structs_p_b_s_a_mparm.html#a3aea5c78775d59b5c898d0b36cf9f244", null ],
    [ "surffil", "structs_p_b_s_a_mparm.html#a33e77b21eeab03b0c506cb4979143bb8", null ],
    [ "tolsp", "structs_p_b_s_a_mparm.html#acd434bcf59cf01b344786d9ab4ef90e1", null ],
    [ "type", "structs_p_b_s_a_mparm.html#ac9a66f4d1b16f4ba2dcb8e6bb34045db", null ]
];