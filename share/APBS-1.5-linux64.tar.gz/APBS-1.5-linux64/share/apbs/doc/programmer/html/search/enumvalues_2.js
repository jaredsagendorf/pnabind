var searchData=
[
  ['clist_5fauto_5fdomain',['CLIST_AUTO_DOMAIN',['../group___vclist.html#gga4efd3ee8fc4f3862c08a8ccd268dfd78a1115764c7ab2cb3ec7c0d11715b1df7c',1,'vclist.h']]],
  ['clist_5fmanual_5fdomain',['CLIST_MANUAL_DOMAIN',['../group___vclist.html#gga4efd3ee8fc4f3862c08a8ccd268dfd78a7d10f403f2733d4b215befcba67d2ea1',1,'vclist.h']]]
];
