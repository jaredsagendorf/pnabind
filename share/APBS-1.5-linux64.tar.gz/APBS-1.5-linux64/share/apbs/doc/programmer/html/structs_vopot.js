var structs_vopot =
[
    [ "bcfl", "structs_vopot.html#a309c773e3e7c928a3e7a7e8e356d85a6", null ],
    [ "mgrid", "structs_vopot.html#ac1652d13f576e15dd5fb52dadc03f30c", null ],
    [ "pbe", "structs_vopot.html#a31a61d9da3a83d7c0328aaaffc6f9a8d", null ]
];