var searchData=
[
  ['d2bspline4',['d2bspline4',['../vpmg_8c.html#a9e0486c0940668c5db8b56f165c474b6',1,'d2bspline4(double x):&#160;vpmg.c'],['../vpmg_8h.html#afa58365e9d16b810f6fe926558650108',1,'d2bspline4(double x):&#160;vpmg.c']]],
  ['d3bspline4',['d3bspline4',['../vpmg_8c.html#addf938597bc4a997f8766856d8d59de1',1,'d3bspline4(double x):&#160;vpmg.c'],['../vpmg_8h.html#a1d34366ccb5b81c8d1ad1826aea7003e',1,'d3bspline4(double x):&#160;vpmg.c']]],
  ['dbspline2',['dbspline2',['../vpmg_8c.html#a8a4a959a2448c20bfc3660f04077892e',1,'dbspline2(double x):&#160;vpmg.c'],['../vpmg_8h.html#a8a4a959a2448c20bfc3660f04077892e',1,'dbspline2(double x):&#160;vpmg.c']]],
  ['dbspline4',['dbspline4',['../vpmg_8c.html#aaefa250362d354e032dd1d104cfea094',1,'dbspline4(double x):&#160;vpmg.c'],['../vpmg_8h.html#a91d1557ecff0ea7809aface06c0c179e',1,'dbspline4(double x):&#160;vpmg.c']]]
];
