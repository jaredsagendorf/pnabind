var structs_valist =
[
    [ "atoms", "structs_valist.html#abcf7d483565ac8ac342a6dd0af8ee18d", null ],
    [ "center", "structs_valist.html#a9da2c4f10aed3a86628aad3dd87c9d6a", null ],
    [ "charge", "structs_valist.html#ab3eb30b2f3f9c5ff812ea037220be570", null ],
    [ "maxcrd", "structs_valist.html#a012ba7376c6e5d018df5e255313218f3", null ],
    [ "maxrad", "structs_valist.html#a85cc3ff81cebdd08e19664c66b3f6564", null ],
    [ "mincrd", "structs_valist.html#a664a785fea9227e461310ece125db769", null ],
    [ "number", "structs_valist.html#a7106e2abc437ad981830d14176d15f09", null ],
    [ "vmem", "structs_valist.html#adfacdf16f7a3cf04b35f4821208b5bdd", null ]
];