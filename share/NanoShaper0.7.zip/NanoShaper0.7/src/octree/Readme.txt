This source code was obtained from http://nomis80.org/code/.
Documentation can be found at http://nomis80.org/code/doc/.

Contact the author: Simon Perreault <nomis80@nomis80.org>


!!! THIS CODE IS LICENSED UNDER THE GNU PUBLIC LICENSE !!!

The full text of the license can be found in the accompanying License.txt. It
is surprisingly readable, you should try it.

If you are not satisfied with the terms of this license and would like
something more permissive, contact me: Simon Perreault <nomis80@nomis80.org>.
We can probably work something out.
