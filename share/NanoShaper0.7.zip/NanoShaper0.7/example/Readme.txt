
The file conf.prm is the configuration file with all the available flags.
Its settings are suitable for a 64 bit machine with 8 GB RAM.

The file conf32.prm has more conservative settings suitable for a 32 bit machine
with 4 GB of RAM. This is more suitable for molecules with less than 100k atoms
on this kind of machine.